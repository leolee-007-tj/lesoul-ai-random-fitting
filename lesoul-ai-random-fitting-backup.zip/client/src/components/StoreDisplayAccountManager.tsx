import { trpc } from "@/lib/trpc";
import { KeyRound, MonitorPlay } from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";

type StoreDisplayAccount = { displayName?: string; user: { id: number; username: string | null; name: string | null; isActive: number } };

export function StoreDisplayAccountManager({ accounts, onChanged }: { accounts: StoreDisplayAccount[]; onChanged: () => void }) {
  const { i18n } = useTranslation();
  const locale = i18n.language.startsWith("ko") ? "ko" : i18n.language.startsWith("zh") ? "zh" : "en";
  const copy = locale === "ko"
    ? { title: "매장 디스플레이 계정", body: "이 계정은 결제 없이 큰 상품을 좌우로 둘러보는 전용 계정입니다.", id: "디스플레이 ID", password: "비밀번호", name: "표시 이름 (선택)", create: "디스플레이 계정 저장", created: "디스플레이 계정이 생성되었습니다", active: "활성", inactive: "비활성", reset: "비밀번호 재설정", save: "저장", noAccounts: "아직 디스플레이 계정이 없습니다.", duplicate: "이미 사용 중인 디스플레이 ID입니다.", idLabel: "ID", error: "요청을 처리하지 못했습니다. 다시 시도해 주세요." }
    : locale === "zh"
      ? { title: "店铺展示账户", body: "该账户仅用于免支付左右浏览大图商品。", id: "展示 ID", password: "密码", name: "显示名称（可选）", create: "保存展示账户", created: "展示账户已创建", active: "启用", inactive: "停用", reset: "重设密码", save: "保存", noAccounts: "暂无展示账户。", duplicate: "该展示 ID 已被使用。", idLabel: "ID", error: "无法完成请求，请稍后重试。" }
      : { title: "STORE DISPLAY ACCOUNTS", body: "These accounts only browse large product images horizontally without payment features.", id: "DISPLAY ID", password: "PASSWORD", name: "Display name (optional)", create: "SAVE DISPLAY ACCOUNT", created: "Display account created", active: "Active", inactive: "Inactive", reset: "Reset password", save: "Save", noAccounts: "No display accounts yet.", duplicate: "This display ID is already in use.", idLabel: "ID", error: "We couldn't complete the request. Please try again." };
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [notice, setNotice] = useState("");
  const [resettingId, setResettingId] = useState<number | null>(null);
  const [resetPassword, setResetPassword] = useState("");
  const create = trpc.operations.createStoreDisplayAccount.useMutation({ onSuccess: (result) => { setUsername(""); setPassword(""); setDisplayName(""); setNotice(`${copy.created}: ${result.username}`); onChanged(); }, onError: (error) => setNotice(error.message.includes("STORE_DISPLAY_ID_ALREADY_EXISTS") ? copy.duplicate : copy.error) });
  const update = trpc.operations.updateStoreDisplayAccount.useMutation({ onSuccess: () => { setResettingId(null); setResetPassword(""); setNotice(copy.save); onChanged(); }, onError: () => setNotice(copy.error) });
  const pending = create.isPending || update.isPending;
  return <section className="mt-5 rounded-2xl border border-[#e2ddd5] bg-white p-4">
    <div className="flex items-center gap-2"><MonitorPlay size={16} /><p className="text-[10px] font-bold tracking-[.14em] text-[#766b60]">{copy.title}</p></div>
    <p className="mt-3 text-xs leading-5 text-[#675e55]">{copy.body}</p>
    <form onSubmit={(event) => { event.preventDefault(); setNotice(""); create.mutate({ username, password, displayName: displayName || undefined }); }} className="mt-4 grid gap-2 sm:grid-cols-3">
      <label className="text-[10px] font-bold text-[#655c53]">{copy.id}<input value={username} onChange={(event) => setUsername(event.target.value)} required minLength={3} className="mt-1 h-10 w-full rounded-xl border border-[#ddd6cc] px-3 text-sm" /></label>
      <label className="text-[10px] font-bold text-[#655c53]">{copy.password}<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={8} autoComplete="new-password" className="mt-1 h-10 w-full rounded-xl border border-[#ddd6cc] px-3 text-sm" /></label>
      <label className="text-[10px] font-bold text-[#655c53]">{copy.name}<input value={displayName} onChange={(event) => setDisplayName(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-[#ddd6cc] px-3 text-sm" /></label>
      <button disabled={pending} className="h-10 rounded-xl bg-black text-[11px] font-bold text-white disabled:opacity-50 sm:col-span-3">{copy.create}</button>
    </form>
    {notice && <p className="mt-3 rounded-xl bg-[#f5f1eb] p-2 text-[11px] text-[#655c53]">{notice}</p>}
    <div className="mt-4 space-y-2">{accounts.length ? accounts.map((account) => <article key={account.user.id} className="rounded-xl bg-[#f7f4ef] p-3">
      <div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="truncate text-xs font-semibold">{account.displayName || account.user.name || copy.title}</p><p className="mt-1 text-[10px] font-semibold tracking-[.08em] text-[#6d6258]">{copy.idLabel} · {account.user.username}</p><p className="mt-1 text-[10px] text-[#776e65]">{account.user.isActive ? copy.active : copy.inactive}</p></div><button type="button" onClick={() => update.mutate({ userId: account.user.id, isActive: !Boolean(account.user.isActive) })} disabled={pending} className="rounded-lg border border-[#cdbfb1] px-2.5 py-1.5 text-[10px] font-bold">{account.user.isActive ? copy.inactive : copy.active}</button></div>
      {resettingId === account.user.id ? <div className="mt-3 flex gap-2"><input type="password" value={resetPassword} onChange={(event) => setResetPassword(event.target.value)} minLength={8} autoComplete="new-password" className="h-9 min-w-0 flex-1 rounded-lg border border-[#ddd6cc] px-2 text-xs" /><button type="button" onClick={() => update.mutate({ userId: account.user.id, newPassword: resetPassword })} disabled={resetPassword.length < 8 || pending} className="rounded-lg bg-black px-3 text-[10px] font-bold text-white">{copy.save}</button></div> : <button type="button" onClick={() => setResettingId(account.user.id)} className="mt-3 inline-flex items-center gap-1 text-[10px] font-bold text-[#655c53]"><KeyRound size={12} />{copy.reset}</button>}
    </article>) : <p className="text-sm text-[#746a61]">{copy.noAccounts}</p>}</div>
  </section>;
}
